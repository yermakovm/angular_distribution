import {Component, OnInit, Inject} from "@angular/core";
import { DataService} from "./data.service";
import {Subscription} from "rxjs";
import { faSitemap, faPlusCircle, faHistory, faLongArrowAltDown, faLongArrowAltUp} from '@fortawesome/free-solid-svg-icons';
import { ActivatedRoute } from "@angular/router";

@Component({
    selector: "app-root",
    templateUrl: "./app.component.html",
    styleUrls: ["./app.component.css"]
})
export class AppComponent implements OnInit {
    faLongArrowAltDown=faLongArrowAltDown;
    faLongArrowAltUp=faLongArrowAltUp;
    chartsOpened=false;
    faPlusCircle=faPlusCircle;
    faHistory=faHistory;
    updatedMins=0;
    faSitemap=faSitemap;
    dataService: DataService;
    isDataAvailable:boolean=false;
    loading:boolean = false;
    private subscription: Subscription;
    smes: any;
    totalLoad: number = 0;
    user: any={};
    event={};
    private querySubscription: Subscription;
     constructor(@Inject(DataService) dataService: DataService, private route: ActivatedRoute) {
        this.dataService = dataService;
    }
    
    
    
    async ngOnInit(){

     this.updatedMins = Number(await this.dataService.GetSyncTime().toPromise());
     this.LoadData();
    }
    AddSme(form)
    {
        this.updatedMins=0;
        form.name;
        let temp = {
            name: form.name,
            teams:[],
            load:0,
            team: "",
            avatar: "assets/avatar.png"
        }
        this.smes.push(temp);
    }
    chartToggle(){
        this.chartsOpened=!this.chartsOpened;
    }
    LoadData() {
        this.loading=true;
        //progressbar fix
        this.totalLoad =0;
        this.smes=[];
        this.dataService.GetData().subscribe((data) => {
            this.dataService.smes=data;
            this.smes=this.dataService.smes;
            this.dataService.assignColor();
            this.dataService.assignLevel();
            this.smes.forEach(sme => {
            this.totalLoad += sme.load;
            this.isDataAvailable = true;
            this.loading=false;
        });
            });
        
        }
    }