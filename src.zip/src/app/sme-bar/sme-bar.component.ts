import { Component, OnInit, Input, Inject } from "@angular/core";
import { SortablejsOptions } from "angular-sortablejs";
import { DataService } from "./../data.service";
import { faTimes, faUserPlus, faUsers } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: "sme-bar",
  templateUrl: "./sme-bar.component.html",
  styleUrls: ["./sme-bar.component.css"],
  //providers: [SortableService]

})
export class SMEBar implements OnInit {
  currentRate = 0;

  faTimes = faTimes;
  faUserPlus=faUserPlus;
  faUsers=faUsers;
  @Input() name: string;
  @Input() teams;
  @Input() avatar:string;
  @Input() load: number;
  @Input() totalLoad: any;
  @Input() id: number;
  csnumber: number;
  progressbarLoad: number;
  progressbarColor: string;
  toggle = false;
  dataService: DataService;
  constructor(@Inject(DataService) dataService: DataService) {
    this.dataService = dataService;
  }

  options: SortablejsOptions = {
    group: "teams",
    animation: 150,
    onRemove: (event: any) => {
      this.updateLoad();
    },
    onAdd: (event: any) => {
      this.updateLoad();
    }
  };
    //each SME calls API to update himself in db
    onSortAPICall()
    {
        //console.log(this.name+" is calling API...");
    }
    DeleteSME(){
        for( var i = 0; i < this.dataService.smes.length; i++){ 
   if ( this.dataService.smes[i].name === this.name) {
     this.dataService.smes.splice(i, 1); 
   }
   this.dataService.notifyOther({
      option: "call_other",
      value: "From sme-bar"
    });
}
        
    }
  updateLoad() {
      this.onSortAPICall();
      this.csnumber =0;
      this.progressbarLoad=0;
    this.teams.forEach(team => {
      this.csnumber += team.teammates.length;
    });
    
    let load: number = 0;
    this.teams.forEach(team => {
      load += team.total_weight;
    });
    this.load = load;
    this.progressbarLoad = Math.floor((load / this.totalLoad) * 100);
    let color: string = "#ffc107";
    if (+this.progressbarLoad < 50) color = "#28a745";
    else if (+this.progressbarLoad > 75) color = "#dc3545";
    this.progressbarColor = color;
    this.dataService.totalCount();
    this.dataService.notifyOther({
      option: "call_other",
      value: "From sme-bar"
    });
    this.BlendTeamColors();
  }

  ngOnInit() {
    this.updateLoad();
   
    
  }
  
  BlendTeamColors(){
             var cslist= document.getElementsByName('teammate');
    Array.from(cslist).forEach(cs => {
        const style = getComputedStyle(cs);
        let rgb = style["background-color"].substring(4, style["background-color"].length-1)
         .replace(/ /g, '')
         .split(',');
        cs.style.backgroundColor=`rgba(${rgb[0]},${rgb[1]},${rgb[2]},0.2)`;
    })
  }
  
  ngAfterViewInit(){
    this.BlendTeamColors();
  }

}
