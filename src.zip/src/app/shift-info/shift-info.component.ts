import {
	Component,
	OnInit,
	Input,
	Inject
} from "@angular/core";
import {
	DataService
} from "./../data.service";
import {
	Subscription
} from "rxjs";
import Chart from 'chart.js';

@Component({
	selector: "shift-info",
	templateUrl: "./shift-info.component.html",
	styleUrls: ["./shift-info.component.css"]
})
export class ShiftInfo implements OnInit {
	dataService: DataService;
	private subscription: Subscription;
	smeList: any = "";
	trList: any = "";
	RR: "";
	summary: string = "";
	chartData: object;
	statsData: object;
	smes: any;
	
	constructor(@Inject(DataService) dataService: DataService) {
		this.dataService = dataService;
	}

	ngOnInit() {
		let cities = this.dataService.totalCount();
		this.chartData = {
			datasets: [{
				label: 'Shift composition',
				data: [this.dataService.stats.newbee, this.dataService.stats.padawan, this.dataService.stats.guru, this.dataService.stats.jedi],
				backgroundColor: [
					'#8ae4ff',
					'#ffd68a',
					'#ff80ea',
					'#91ffa2'
				],	
				hoverBackgroundColor: [
					'#58adc7',
					'#f0bb59',
					'#d647be',
					'#63d474'
				]
			}],
			labels: [
				'Newbee',
				'Padawan',
				'Guru',
				'Jedi'
			]
		};
		this.statsData = {
			datasets: [{
				label: 'Stats',
				data: [cities[0].count, cities[1].count, cities[2].count],
				backgroundColor: [
					'#97ddde',
					'#88cf9c',
					'#f0edb1',
				],
				hoverBackgroundColor: [
					'#82bebf',
					'#7bba8d',
					'#d4d19d',
				]
			}],
			labels: [
				'Kharkiv',
				'Lviv',
				'Dnipro',
			]
		};

		let ctx = document.getElementById('expChart');
		let myDoughnutChart = new Chart(ctx, {
			type: 'doughnut',
			data: this.chartData,
			options: {
				legend: {
					display: true,
					labels: {
						fontColor: 'black',
						boxWidth:20,
						padding:7
					},
					position:'left',
				},
				title: {
					display: true,
					text: 'Experience',
					fontSize:16
				}
			}

		});

		let ctx2 = document.getElementById('summaryChart');
		let mystatsChart = new Chart(ctx2, {
			type: 'doughnut',
			data: this.statsData,
			options: {
				legend: {
					display: true,
					labels: {
						fontColor: 'black',
						boxWidth:20,
						padding:7
					},
					position:'left'
				},
				title: {
					display: true,
					text: 'Cities',
					fontSize:16
				}
			}
		});
		this.smes = this.dataService.smes;
	}
}