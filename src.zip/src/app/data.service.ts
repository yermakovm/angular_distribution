import {Injectable} from "@angular/core";
import {Subject} from "rxjs";
import { HttpClient} from '@angular/common/http';

@Injectable()
export class DataService {
    private notify = new Subject < any > ();
    smes: any;
    event={};
    stats={
    newbee:0,
    padawan:0,
    guru:0,
    jedi:0
    };
    shift_number: string;
    notifyObservable$ = this.notify.asObservable();
    totalNumber: number = 0;
    public notifyOther(data: any) {
        if (data) {
            this.notify.next(data);
        }
    }
    constructor(private http: HttpClient) {
        
    }
    GetUser(){
        return this.http.get('https://mikesandbox.net:8043/client');
    }
    GetSyncTime() {
        return this.http.get('https://mikesandbox.net/api/Distribution/synctime');
    }

    parseFlockEvent = () =>{
    var url_string = window.location.href;
    var url = new URL(url_string);
    var event = url.searchParams.get("flockEvent");
    return JSON.parse(event);
    }
 GetData() {
     
     let today = new Date();
     let hour = today.getHours();
     if(hour<8)
        this.shift_number = "night";
    if (hour>=8&&hour<16)
        this.shift_number = "morning";
    if(hour>=16)
     this.shift_number = "evening";
     return this.http.get('https://mikesandbox.net/api/Distribution/');
 }
    updateData(arr: any) {
        this.smes.next(arr);
    }
    
    assignLevel(): void {

        this.smes.forEach(sme => {
            sme.teams.forEach(team => {
                team.teammates.forEach(cs => {
                    cs["levelClassName"] = cs.level.replace(/\s+/g, "-").toLowerCase();
                    switch (cs.levelClassName) {
                      case "newbee":
                        cs.stars=1;
                        this.stats.newbee++;
                        break;
                      case "skilled-padawan":
                        cs.stars=2;
                        this.stats.padawan++;
                        break;
                      case "google-guru":
                        this.stats.guru++;  
                        cs.stars=3;
                        break;
                        case "jedi-master":
                        this.stats.jedi++;
                        cs.stars=4;
                        break;
                    }
                });
            });
        });
    }
    assignColor(): void {
        this.smes.forEach(sme => {
            sme.teams.forEach(team => {
                team["className"] = team.name.replace(/\s+/g, "-").toLowerCase();
            });
        });
    }
    
    totalCount(): any {
        let cities = [{
                name: "Kharkiv",
                count: 0
            },
            {
                name: "Lviv",
                count: 0
            },
            {
                name: "Dnipro",
                count: 0
            }
        ];
        
        this.smes.forEach(sme => {
              if (sme.location==="Kharkiv") cities[0].count++;
                if (sme.location==="Lviv")  cities[1].count++;
                if (sme.location==="Dnipro") cities[2].count++;
            sme.hasKharkiv=false;sme.hasLviv=false;sme.hasDnipro=false;
            sme.hasOnly=[];
            sme.teams.forEach(team => {
                team.teammates.forEach(cs => {
                    if (cs.location==="Kharkiv") {
                        cities[0].count++;
                        sme.hasKharkiv=true;
                    }
                    if (cs.location==="Lviv") {
                        cities[1].count++;
                        sme.hasLviv=true;
                    }
                    if (cs.location==="Dnipro") {
                        cities[2].count++;
                        sme.hasDnipro=true;
                    }
                });
            });
        });
        this.smesHaveSingleLocation();
        return cities;
    }

    smesHaveSingleLocation(){
      for (let i = 0; i < this.smes.length; i++) {
        let temp = this.smes.slice();
        temp.splice(i,1);
        let kh=temp.every(x=>!x.hasKharkiv);
        let lv=temp.every(x=>!x.hasLviv);
        let dn=temp.every(x=>!x.hasDnipro);
        if(this.smes[i].hasKharkiv&&kh)
            this.smes[i].hasOnly.push("Kharkiv");
        if(this.smes[i].hasLviv&&lv)
            this.smes[i].hasOnly.push("Lviv");
        if(this.smes[i].hasDnipro&&dn)
            this.smes[i].hasOnly.push("Dnipro");
        }
    }
    
    getTRList = () => {
        let arr = [];
        this.smes.forEach(sme => {
            sme.teams.forEach(team => {
                team.teammates.forEach(cs => {
                    if (cs.shift_role === "Tickets only") arr.push(cs);
                });
            });
        });
        return arr;
    };

    getSmeList = () => {
        let arr = [];
        this.smes.forEach(sme => {
            arr.push(sme);
        });
        return arr;
    };
    getRR = () => {
        let rr;
        this.smes.forEach(sme => {
            sme.teams.forEach(team => {
                team.teammates.forEach(cs => {
                    if (cs.shift_role === "Flock") rr = cs;
                });
            });
        });
        return rr;
    };
    getPE = () => {
        let pe = [];
        this.smes.forEach(sme => {
            sme.teams.forEach(team => {
                team.teammates.forEach(cs => {
                    if (cs.shift_role === "OX") pe.push(cs);
                });
            });
        });
        return pe;
    };

    getDistribution = () => {
        return this.smes;
    };
}